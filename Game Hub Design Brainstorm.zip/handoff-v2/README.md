# Can You Daily? — Hub v2 (list + hover preview)

Reference: `Hub Level Select v2.dc.html` (open in a browser). Values below are exact.

## Concept
Minimal white hub. Left: today's games as a list. Right: a preview card for the hovered/tapped game.
- **Only Can You Survive?** shows the pixel-art card.
- **Every other game** shows its own card design (TBD) — currently a neutral placeholder.
- The hub itself uses no pixel styling.

## Fonts (Google Fonts)
- **Schibsted Grotesk** 400/500/700/800 — hub UI, non-Survive cards
- **JetBrains Mono** 400/500 — issue numbers, small labels
- **Silkscreen** 400/700 + **Pixelify Sans** 400 — Survive card only

## Page
- Background `#fff`, ink `#141414`, muted `#6b6a66`, soft muted `#9a9893`, dividers `#ecebe7`
- Padding: 40px top, 64px bottom, sides `clamp(20px, 6vw, 100px)`; content max-width 1100px, centered
- Gap between top bar and content: 48px

### Top bar
- Left: `Can You Daily` Schibsted 800 22px, -0.02em; trailing `?` in `#9a9893`
- Right: 40px circular theme toggle, 1px `#e5e4e0` border

### Layout
- Grid: list column (~1/3) + preview (~2/3), gap 48px, align top
- Below ~1000px it stacks: list on top, preview below (`repeat(auto-fit, minmax(min(100%,320px),1fr))`, preview spans 2)

## Left column
- Date `Monday, October 12` — 400 15px muted
- Title `Today's games` — 800 48px, -0.03em, line-height 1.05
- `New games in 01:56:20` — 400 15px muted, countdown 500 `#141414` (counts to daily reset)
- 28px below: game list
  - Top border + each row bottom border 1px `#ecebe7`
  - Row: padding 14px 12px, flex, gap 12px
  - Issue number (`#006`) JetBrains Mono 13px `#9a9893`, 40px fixed width
  - Title `Can You Survive?` Schibsted 700 20px — idle `#55544f`, selected `#141414`
  - Selected row: background `#f6f5f2`, `→` right-aligned
- Interaction: mouseenter + click select (tap on mobile). Recommended: ↑/↓ keys move, Enter plays. Default selection = first game.

## Preview — Can You Survive? (pixel card)
- Background `#121112`; min-height 440px; padding 36px; content split top/bottom
- Stepped pixel corners via clip-path:
  `polygon(0 8px,4px 8px,4px 4px,8px 4px,8px 0,calc(100% - 8px) 0,calc(100% - 8px) 4px,calc(100% - 4px) 4px,calc(100% - 4px) 8px,100% 8px,100% calc(100% - 8px),calc(100% - 4px) calc(100% - 8px),calc(100% - 4px) calc(100% - 4px),calc(100% - 8px) calc(100% - 4px),calc(100% - 8px) 100%,8px 100%,8px calc(100% - 4px),4px calc(100% - 4px),4px calc(100% - 8px),0 calc(100% - 8px))`
- Header: `#006 · DAILY` Silkscreen 400 13px, 0.12em, `#a29a8f`; skull icon right (placeholder: 22px `#d65a3f` square)
- Title: Silkscreen 700 `clamp(36px,5vw,56px)`/1.02 — `CAN YOU` `#f2ebdd`, `SURVIVE` `#d65a3f`, `?` `#e8b94a`
- Description: Pixelify Sans 18px/1.5 `#a29a8f`, max-width 440px
- Footer: `Not started` Pixelify Sans 15px `#a29a8f`; button `PLAY →` Silkscreen 700 18px, bg `#d65a3f`, text `#fff6ea`, padding 10px 22px, hard shadow `0 4px 0 #8a3020`
- Optional: wasteland background art along the bottom edge (as in the current site)

## Preview — all other games (placeholder)
- Background `#f6f5f2`, 1px `#ecebe7` border, radius 16px, min-height 440px, padding 32px, 20px gap
- Header: `#014 · DAILY` JetBrains Mono 13px `#6b6a66`
- Title `Can You Escape?` Schibsted 800 44px, -0.03em
- Description Schibsted 400 17px/1.5 `#55544f`, max-width 440px
- Art area: striped placeholder, fills remaining height — replace with each game's own card design
- Footer: `Not started` 15px muted; button `Play →` Schibsted 600 16px, `#141414` bg, white text, pill radius, padding 12px 22px

## Data
Per game: `{ num, name, desc, href }`. Rendering rule: `name === 'Survive'` → pixel card, otherwise → that game's own card component (placeholder until designed).

Placeholder games: #006 Survive, #014 Escape, #021 Spell, #009 Recall, #017 Balance, #003 Sneak.

## States to add later
In progress (`RESUME →`), completed (score / results), streak.
